# 차트 DB
CREATE TABLE `chart` (
   `dong` varchar(20) NOT NULL,
   `cnt` int NOT NULL
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# 동 DB
CREATE TABLE `dongcode` (
   `num` int DEFAULT NULL,
   `city` text,
   `code` bigint DEFAULT NULL,
   `dongcode` int DEFAULT NULL,
   `gugun` text,
   `dong` text,
   `lat` double DEFAULT NULL,
   `lng` double DEFAULT NULL
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

# 구군 DB
CREATE TABLE `guguncode` (
   `gugun_code` varchar(10) NOT NULL,
   `gugun_name` varchar(30) DEFAULT NULL,
   PRIMARY KEY (`gugun_code`)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# 시도 DB
CREATE TABLE `sidocode` (
   `sido_code` varchar(10) NOT NULL,
   `sido_name` varchar(30) DEFAULT NULL,
   PRIMARY KEY (`sido_code`)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# 아파트거래정보 DB
CREATE TABLE `housedeal` (
   `no` int DEFAULT NULL,
   `dong` text,
   `AptName` text,
   `code` int DEFAULT NULL,
   `dealAmount` text,
   `buildYear` int DEFAULT NULL,
   `dealYear` int DEFAULT NULL,
   `dealMonth` int DEFAULT NULL,
   `dealDay` int DEFAULT NULL,
   `area` double DEFAULT NULL,
   `floor` int DEFAULT NULL,
   `jibun` text,
   `type` int DEFAULT NULL,
   `rentMoney` text
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# 아파트 정보DB
CREATE TABLE `houseinfo` (
   `no` int NOT NULL AUTO_INCREMENT,
   `dong` varchar(30) NOT NULL,
   `AptName` varchar(50) NOT NULL,
   `code` varchar(30) NOT NULL,
   `buildYear` varchar(30) DEFAULT NULL,
   `jibun` varchar(30) DEFAULT NULL,
   `lat` varchar(30) DEFAULT NULL,
   `lng` varchar(30) DEFAULT NULL,
   `img` varchar(50) DEFAULT NULL,
   PRIMARY KEY (`no`)
 ) ENGINE=InnoDB AUTO_INCREMENT=5996 DEFAULT CHARSET=utf8;

# 질문 게시판 DB
CREATE TABLE `qna_board` (
   `qna_no` int NOT NULL AUTO_INCREMENT COMMENT '질문번호',
   `qna_title` varchar(300) NOT NULL COMMENT '질문제목',
   `qna_content` varchar(4000) NOT NULL COMMENT '질문내용',
   `qna_userid` varchar(20) NOT NULL COMMENT '질문자아이디',
   `qna_datetime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '질문일시',
   `reply_content` varchar(4000) DEFAULT NULL COMMENT '답변내용',
   `reply_datetime` timestamp NULL DEFAULT NULL COMMENT '답변일시',
   `reply_userid` varchar(20) DEFAULT NULL COMMENT '답변자아이디',
   PRIMARY KEY (`qna_no`),
   KEY `qna_to_user_fk1` (`qna_userid`),
   KEY `qna_to_user_fk2` (`reply_userid`),
   CONSTRAINT `qna_to_user_fk1` FOREIGN KEY (`qna_userid`) REFERENCES `ssafy_member` (`userid`),
   CONSTRAINT `qna_to_user_fk2` FOREIGN KEY (`reply_userid`) REFERENCES `ssafy_member` (`userid`)
 ) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='질문게시판';

# 질문 답변 회원 정보 DB
CREATE TABLE `ssafy_member` (
   `userid` varchar(20) NOT NULL,
   `username` varchar(20) NOT NULL,
   `userpwd` varchar(100) NOT NULL,
   `email` varchar(2000) DEFAULT NULL,
   `address` varchar(2000) DEFAULT NULL,
   `joindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
   PRIMARY KEY (`userid`)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# 로그인 회원 정보 DB
CREATE TABLE `ssafy_member2` (
   `userno` int NOT NULL AUTO_INCREMENT,
   `userid` varchar(20) NOT NULL,
   `username` varchar(20) NOT NULL,
   `userpwd` varchar(100) NOT NULL,
   `telephone` varchar(20) DEFAULT NULL,
   `email` varchar(200) DEFAULT NULL,
   `address` varchar(2000) DEFAULT NULL,
   `joindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
   PRIMARY KEY (`userno`),
   UNIQUE KEY `userid` (`userid`)
 ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
